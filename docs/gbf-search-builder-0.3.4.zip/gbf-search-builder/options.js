import {readSettings,writeValue,SETTINGS_KEY,LIMIT} from './settings.mjs';
let settings=await readSettings();
const notice=document.getElementById('notice');
const names={tab:'새 탭',window:'새 창',current:'현재 탭',copy:'링크 복사'};
async function save(){await writeValue(SETTINGS_KEY,settings);notice.textContent='저장했습니다.';}
for(const select of document.querySelectorAll('[data-site]')){
  for(const [value,label]of Object.entries(names)){const option=document.createElement('option');option.value=value;option.textContent=label;select.append(option);}
  select.value=settings.search[select.dataset.site];select.addEventListener('change',async()=>{settings.search[select.dataset.site]=select.value;try{await save();}catch{notice.textContent='저장하지 못했습니다. 다시 시도하세요.';}});
}
for(const kind of ['bosses','conditions']){
  const prefix=kind==='bosses'?'boss':'condition',form=document.getElementById(prefix+'-form'),list=document.getElementById(prefix+'-list');
  let editId=null;
  function reset(){editId=null;form.reset();form.querySelector('[type=submit]').textContent='추가';form.querySelector('.cancel').hidden=true;render();}
  function render(){
    list.replaceChildren();document.getElementById(prefix+'-count').textContent=settings[kind].length+' / '+LIMIT;
    for(const item of settings[kind]){
      const row=document.createElement('div');row.className='item';
      for(const key of ['ko','jp','en']){const span=document.createElement('span');span.textContent=item[key]||'미입력';if(!item[key])span.className='missing';row.append(span);}
      const edit=document.createElement('button');edit.type='button';edit.textContent='수정';edit.onclick=()=>{editId=item.id;for(const key of ['ko','jp','en'])form.elements[key].value=item[key];form.querySelector('[type=submit]').textContent='저장';form.querySelector('.cancel').hidden=false;render();form.elements.ko.focus();};
      const remove=document.createElement('button');remove.type='button';remove.textContent='삭제';remove.onclick=async()=>{const previous=settings[kind];settings[kind]=settings[kind].filter(x=>x.id!==item.id);try{await save();reset();}catch{settings[kind]=previous;notice.textContent='삭제 내용을 저장하지 못했습니다.';render();}};row.append(edit,remove);list.append(row);
    }
    form.querySelector('[type=submit]').disabled=!editId&&settings[kind].length>=LIMIT;
  }
  form.querySelector('.cancel').onclick=reset;
  form.addEventListener('submit',async e=>{
    e.preventDefault();const item={id:editId||'custom-'+crypto.randomUUID(),ko:form.elements.ko.value.trim(),jp:form.elements.jp.value.trim(),en:form.elements.en.value.trim()};
    if(!item.ko||(!item.jp&&!item.en)){notice.textContent='한글명과 일본어명 또는 영문명 중 하나 이상을 입력하세요.';return;}
    if(!editId&&settings[kind].length>=LIMIT){notice.textContent='최대 '+LIMIT+'개까지 추가할 수 있습니다.';return;}
    const previous=settings[kind];settings[kind]=editId?settings[kind].map(x=>x.id===editId?item:x):[...settings[kind],item];
    try{await save();reset();}catch{settings[kind]=previous;notice.textContent='저장하지 못했습니다. 다시 시도하세요.';}
  });render();
}
