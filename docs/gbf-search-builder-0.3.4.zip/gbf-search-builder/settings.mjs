export const SETTINGS_KEY='gbf-search-settings-v1', STATE_KEY='gbf-search-state-v2';
export const LIMIT=6;
export const modes=['tab','window','current','copy'];
export function normalizeSettings(input={}){
  const list=items=>(Array.isArray(items)?items:[]).filter(x=>x&&typeof x.id==='string'&&typeof x.ko==='string').map(x=>({id:x.id,ko:x.ko.trim().slice(0,12),jp:typeof x.jp==='string'?x.jp.trim().slice(0,80):'',en:typeof x.en==='string'?x.en.trim().slice(0,80):''})).filter(x=>x.ko&&(x.jp||x.en)).filter((x,i,a)=>a.findIndex(y=>y.id===x.id)===i).slice(0,LIMIT);
  return {search:Object.fromEntries(['youtube','google','x'].map(k=>[k,modes.includes(input.search?.[k])?input.search[k]:'tab'])),bosses:list(input.bosses),conditions:list(input.conditions)};
}
export async function readValue(key){
  if(globalThis.chrome?.storage?.local)return (await chrome.storage.local.get(key))[key];
  try{return JSON.parse(localStorage.getItem(key)||'null');}catch{return null;}
}
export async function writeValue(key,value){
  if(globalThis.chrome?.storage?.local)await chrome.storage.local.set({[key]:value});
  else localStorage.setItem(key,JSON.stringify(value));
}
export async function readSettings(){return normalizeSettings(await readValue(SETTINGS_KEY)||{});}
export async function readState(){
  let state=await readValue(STATE_KEY);
  if(!state){try{state=JSON.parse(localStorage.getItem('gbf-search-builder-v1')||'{}')||{};}catch{state={};}await writeValue(STATE_KEY,state);}
  return state;
}
export function observeSettings(callback){
  if(globalThis.chrome?.storage?.onChanged)chrome.storage.onChanged.addListener((changes,area)=>{if(area==='local'&&changes[SETTINGS_KEY])callback(normalizeSettings(changes[SETTINGS_KEY].newValue||{}));});
  else addEventListener('storage',e=>{if(e.key===SETTINGS_KEY)readSettings().then(callback);});
}
export function supports(boss,conditions=[]){return {ja:(!boss||Boolean(boss.jp))&&conditions.every(c=>Boolean(c.jp)),en:(!boss||Boolean(boss.en))&&conditions.every(c=>Boolean(c.en))};}
export async function openSettings(){
  if(globalThis.chrome?.runtime?.openOptionsPage)await chrome.runtime.openOptionsPage();
  else window.open('options.html','_blank','noopener');
}
export async function openSearch(url,mode){
  if(mode==='copy'){await navigator.clipboard.writeText(url);return;}
  if(globalThis.chrome?.tabs){
    if(mode==='window')await chrome.windows.create({url});
    else if(mode==='current'){const [tab]=await chrome.tabs.query({active:true,currentWindow:true});if(!tab?.id)throw Error('현재 탭을 찾을 수 없습니다.');await chrome.tabs.update(tab.id,{url});}
    else await chrome.tabs.create({url});
  }else if(mode==='current')location.assign(url);
  else window.open(url,'_blank',mode==='window'?'noopener,width=1000,height=800':'noopener');
}
